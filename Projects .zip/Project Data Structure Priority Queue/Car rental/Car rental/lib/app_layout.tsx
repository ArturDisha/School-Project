import './globals.css'
import { Inter } from 'next/font/google'
import Link from 'next/link'
import React from 'react'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Car Rental Website',
  description: 'List and rent cars easily',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-blue-600 text-white p-4">
          <nav className="container mx-auto flex justify-between items-center">
            <Link href="/" className="text-2xl font-bold">CarRental</Link>
            <div>
              <Link href="/dashboard" className="mr-4">Dashboard</Link>
              <Link href="/auth/signin">Sign In</Link>
            </div>
          </nav>
        </header>
        <main className="container mx-auto mt-8 px-4">
          {children}
        </main>
        <footer className="bg-gray-200 mt-8 p-4 text-center">
          <p>&copy; 2023 CarRental. All rights reserved.</p>
        </footer>
      </body>
    </html>
  )
}