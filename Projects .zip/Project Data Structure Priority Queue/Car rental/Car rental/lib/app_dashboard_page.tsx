'use client'

import { useState } from 'react'
import Link from 'next/link'
import React from 'react'

export default function Dashboard() {
  const [cars, setCars] = useState([
    { id: 1, title: 'Toyota Camry', year: 2020, price: 50 },
    { id: 2, title: 'Honda Civic', year: 2019, price: 45 },
  ])

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Your Dashboard</h1>
      <h2 className="text-2xl font-semibold mb-4">Your Listed Cars</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {cars.map((car) => (
          <div key={car.id} className="border rounded-lg p-4 shadow-md">
            <h3 className="text-xl font-semibold mb-2">{car.title}</h3>
            <p>Year: {car.year}</p>
            <p>Price: ${car.price}/day</p>
            <Link href={`/cars/${car.id}`} className="text-blue-600 hover:underline mt-2 inline-block">
              View Details
            </Link>
          </div>
        ))}
      </div>
      <Link href="/cars/new" className="bg-green-600 text-white px-6 py-3 rounded-lg text-lg hover:bg-green-700 transition-colors mt-8 inline-block">
        Add New Car
      </Link>
    </div>
  )
}