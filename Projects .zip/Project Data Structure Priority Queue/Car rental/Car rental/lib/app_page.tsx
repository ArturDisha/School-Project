import Link from 'next/link'
import React from 'react'

export default function Home() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold mb-8">Welcome to CarRental</h1>
      <p className="text-xl mb-8">Find the perfect car for your next adventure</p>
      <Link href="/cars" className="bg-blue-600 text-white px-6 py-3 rounded-lg text-lg hover:bg-blue-700 transition-colors">
        Browse Cars
      </Link>
    </div>
  )
}