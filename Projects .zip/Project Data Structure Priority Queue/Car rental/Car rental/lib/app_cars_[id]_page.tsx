'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import React from 'react'

export default function CarListing() {
  const { id } = useParams()
  const [car, setCar] = useState(null)

  useEffect(() => {
    // In a real application, you would fetch the car data from an API
    setCar({
      id: id,
      title: 'Toyota Camry',
      year: 2020,
      color: 'Silver',
      features: ['Bluetooth', 'Backup Camera', 'Cruise Control'],
      price: 50,
      owner: 'John Doe',
    })
  }, [id])

  if (!car) {
    return <div>Loading...</div>
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">{car.title}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <img src="/placeholder.svg?height=300&width=400" alt={car.title} className="w-full h-auto rounded-lg shadow-md" />
        </div>
        <div>
          <p className="text-xl mb-4">Price: ${car.price}/day</p>
          <p className="mb-2">Year: {car.year}</p>
          <p className="mb-2">Color: {car.color}</p>
          <h2 className="text-2xl font-semibold mt-4 mb-2">Features:</h2>
          <ul className="list-disc list-inside">
            {car.features.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
          <p className="mt-4">Owner: {car.owner}</p>
          <button className="bg-blue-600 text-white px-6 py-3 rounded-lg text-lg hover:bg-blue-700 transition-colors mt-6">
            Book Now
          </button>
        </div>
      </div>
    </div>
  )
}