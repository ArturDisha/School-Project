import java.util.ArrayList;
import java.util.NoSuchElementException;

public class PriorityQueue {
    private ArrayList<Integer> heap;

    public PriorityQueue() {
        heap = new ArrayList<>();
    }

  
    public void insert(int item) {
        heap.add(item);
        heapifyUp(heap.size() - 1);
    }

    public int delete() {
        if (heap.isEmpty()) {
            throw new NoSuchElementException("delete from empty priority queue");
        }

        int min = heap.get(0);
        int last = heap.remove(heap.size() - 1);

        if (!heap.isEmpty()) {
            heap.set(0, last);
            heapifyDown(0);
        }

        return min;
    }


    public int peek() {
        if (heap.isEmpty()) {
            throw new NoSuchElementException("peek from empty priority queue");
        }
        return heap.get(0);
    }


    public boolean isEmpty() {
        return heap.isEmpty();
    }


    public int size() {
        return heap.size();
    }


    private void heapifyUp(int index) {
        int parentIndex;
        if (index != 0) {
            parentIndex = (index - 1) / 2;
            if (heap.get(index) < heap.get(parentIndex)) {
                swap(index, parentIndex);
                heapifyUp(parentIndex);
            }
        }
    }


    private void heapifyDown(int index) {
        int leftChildIndex = 2 * index + 1;
        int rightChildIndex = 2 * index + 2;
        int smallest = index;

        if (leftChildIndex < heap.size() && heap.get(leftChildIndex) < heap.get(smallest)) {
            smallest = leftChildIndex;
        }

        if (rightChildIndex < heap.size() && heap.get(rightChildIndex) < heap.get(smallest)) {
            smallest = rightChildIndex;
        }

        if (smallest != index) {
            swap(index, smallest);
            heapifyDown(smallest);
        }
    }


    private void swap(int index1, int index2) {
        int temp = heap.get(index1);
        heap.set(index1, heap.get(index2));
        heap.set(index2, temp);
    }

    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue();
        pq.insert(5);
        pq.insert(1);
        pq.insert(3);
        System.out.println("Peek: " + pq.peek()); 
        System.out.println("Delete: " + pq.delete()); 
        System.out.println("Delete: " + pq.delete()); 
        System.out.println("Delete: " + pq.delete()); 
    }
}