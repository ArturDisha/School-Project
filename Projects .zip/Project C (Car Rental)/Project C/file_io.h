//
//  file_io.h
//  Project C
//
//  Created by Artur Disha on 7.6.23.
//

#ifndef FILE_IO_H
#define FILE_IO_H

#include "structures.h"

void saveDataToFile(Car *carHead, Client *clientHead, Reservation *reservHead);
void loadDataFromFile(Car **carHead, Client **clientHead, Reservation **reservHead);

#endif /* FILE_IO_H */
