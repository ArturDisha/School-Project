//
//  file_io.c
//  Project C
//
//  Created by Artur Disha on 7.6.23.
//
#include <stdlib.h>
#include <stdio.h>
#define _GNU_SOURCE
#include <string.h>
#include "file_io.h"
#include "insert.h"



void saveDataToFile(Car *carHead, Client *clientHead, Reservation *reservHead) {
    FILE *file = fopen("data.txt", "w");
    if (file == NULL) {
      printf("Error opening file.");
      return;
    }

   
    Car *carPtr = carHead->next;
    while (carPtr != NULL) {
      fprintf(file, "car|%s|%s|%s|%s|%d|%d|%.3f|%.3f|%.3f|%d|%ld|%ld|%d\n", carPtr->licensePlate, carPtr->marque, carPtr->model, carPtr->fuel, carPtr->year, carPtr->seats, carPtr->fuelCons, carPtr->engineCapacity, carPtr->price, carPtr->isBooked, carPtr->timeBooked, carPtr->timeFreed, carPtr->noTimesBooked);
      carPtr = carPtr->next;
    }

  
    Client *clientPtr = clientHead->next;
    while (clientPtr != NULL) {
      fprintf(file, "client|%d|%s|%s|%s|%s|%s\n", clientPtr->clientId, clientPtr->passportId, clientPtr->firstName, clientPtr->lastName, clientPtr->state, clientPtr->phoneNo);
      clientPtr = clientPtr->next;
    }


    Reservation *reservPtr = reservHead->next;
    while (reservPtr != NULL) {
      fprintf(file, "reservation|%d|%d|%d|%s|%.3f\n", reservPtr->reservationId, reservPtr->clientId, reservPtr->noOfDays, reservPtr->licensePlate, reservPtr->totalPrice);
      reservPtr = reservPtr->next;
    }

    fclose(file);
  }



void loadDataFromFile(Car **carHead, Client **clientHead, Reservation **reservHead) {
    FILE *file = fopen("data.txt", "r");
      if (file == NULL) {
        printf("Error opening file.");
        return;
      }

    
      char line[256];
      while (fgets(line, sizeof(line), file)) {
        char *type = strtok(line, "|");

        if (strcmp(type, "car") == 0) {
          char *licensePlate = strtok(NULL, "|");
          char *marque = strtok(NULL, "|");
          char *model = strtok(NULL, "|");
          char *fuel = strtok(NULL, "|");
          int year = atoi(strtok(NULL, "|"));
          int seats = atoi(strtok(NULL, "|"));
          float fuelCons = atof(strtok(NULL, "|"));
          float engineCapacity = atof(strtok(NULL, "|"));
          float price = atof(strtok(NULL, "|"));
          int isBooked = atoi(strtok(NULL, "|"));
          time_t timeBooked = atol(strtok(NULL, "|"));
          time_t timeFreed = atol(strtok(NULL, "|"));
          int noTimesBooked = atoi(strtok(NULL, "|"));

          insertCarAtEnd(*carHead, licensePlate, marque, model, fuel, year, seats, fuelCons, price, engineCapacity);
          Car *newCar = (*carHead)->next;
          newCar->isBooked = isBooked;
          newCar->timeBooked = timeBooked;
          newCar->timeFreed = timeFreed;
          newCar->noTimesBooked = noTimesBooked;
        }
        else if (strcmp(type, "client") == 0) {
          int clientId = atoi(strtok(NULL, "|"));
          char *passportId = strtok(NULL, "|");
          char *firstName = strtok(NULL, "|");
          char *lastName = strtok(NULL, "|");
          char *state = strtok(NULL, "|");
          char *phoneNo = strtok(NULL, "|");

          insertClientAtEnd(*clientHead, clientId, passportId, firstName, lastName, state, phoneNo);
        }
        else if (strcmp(type, "reservation") == 0) {
          int reservationId = atoi(strtok(NULL, "|"));
          int clientId = atoi(strtok(NULL, "|"));
          int noOfDays = atoi(strtok(NULL, "|"));
          char *licensePlate = strtok(NULL, "|");
          float totalPrice = atof(strtok(NULL, "|"));

         
          }
        }
      

      fclose(file);
    }
